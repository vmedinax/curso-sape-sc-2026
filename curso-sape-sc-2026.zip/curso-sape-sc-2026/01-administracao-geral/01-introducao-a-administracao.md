# Introdução à Administração

## Objetivos de aprendizagem

- Compreender o conceito de administração
- Diferenciar planejamento, organização, direção e controle
- Diferenciar eficiência, eficácia e efetividade

## Administração

Administração é o processo de planejar, organizar, dirigir e controlar recursos para atingir objetivos.

## Funções administrativas

### Planejamento

Define objetivos e caminhos para alcançá-los.

### Organização

Distribui atividades, recursos e responsabilidades.

### Direção

Envolve liderança, motivação, comunicação e condução das pessoas.

### Controle

Compara o resultado alcançado com o resultado planejado e corrige desvios.

## Eficiência, eficácia e efetividade

- Eficiência: uso adequado dos recursos
- Eficácia: alcance dos objetivos
- Efetividade: impacto produzido

## Resumo

- Planejar: decidir antecipadamente
- Organizar: estruturar
- Dirigir: conduzir pessoas
- Controlar: verificar e corrigir
