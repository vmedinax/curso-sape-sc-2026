# Título do capítulo

## 1. Objetivos de aprendizagem

Ao final deste capítulo, a aluna deverá ser capaz de:

- 
- 
- 

## 2. Teoria direcionada

## 3. Exemplos práticos

## 4. Como a banca cobra

## 5. Pegadinhas

## 6. Questões comentadas

### Questão 1

**Enunciado:**

A)  
B)  
C)  
D)  
E)  

**Gabarito:**

**Comentário:**

## 7. Exercícios de fixação

## 8. Resumo do capítulo

## 9. Flashcards

## 10. Revisão

- Revisão em 24 horas:
- Revisão em 7 dias:
- Revisão em 30 dias:
