# Plano de estudos

## Objetivo

Preparação direcionada para a prova de 20 de setembro de 2026.

## Método semanal

- Teoria objetiva
- Questões imediatamente após a teoria
- Revisão dos erros
- Revisão semanal
- Simulado periódico

## Registro mínimo

Para cada sessão de estudo, registrar:

- Disciplina
- Assunto
- Tempo líquido
- Número de questões
- Percentual de acertos
- Principais erros
