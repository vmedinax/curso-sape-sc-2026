# Curso SAPE/SC 2026

Material preparatório direcionado ao concurso da SAPE/SC, com prova prevista para 20 de setembro de 2026.

## Objetivo

Construir um curso completo, organizado por disciplinas, com teoria, resumos, questões comentadas, revisões e simulados.

## Estrutura

- `00-guia-do-candidato`: estratégia, planejamento e metodologia de estudo
- `01-administracao-geral`: fundamentos e teorias da administração
- `02-administracao-publica`: modelos, princípios e gestão pública
- `03-direito-constitucional`: conteúdo constitucional do edital
- `04-direito-administrativo`: atos, poderes, agentes e serviços públicos
- `05-afo`: administração financeira e orçamentária
- `06-licitacoes-e-contratos`: Lei nº 14.133/2021 e temas relacionados
- `07-informatica`: ferramentas, internet, segurança e tecnologia
- `08-portugues`: interpretação, gramática e redação oficial
- `09-raciocinio-logico`: lógica, conjuntos, porcentagem e problemas
- `10-legislacao-especifica`: normas indicadas no edital
- `banco-de-questoes`: questões separadas por disciplina e assunto
- `simulados`: provas completas e gabaritos
- `flashcards`: cartões de revisão
- `mapas-mentais`: sínteses visuais
- `docs`: arquivos Word e PDF finais
- `modelos`: modelos padronizados para novos capítulos

## Padrão de cada capítulo

1. Objetivos de aprendizagem
2. Teoria direcionada
3. Exemplos
4. Como a banca cobra
5. Pegadinhas
6. Questões comentadas
7. Exercícios de fixação
8. Resumo
9. Flashcards
10. Plano de revisão

## Status

Consulte o arquivo [`ROADMAP.md`](ROADMAP.md).
