# Roadmap

## Prioridade 1

- [ ] Validar o conteúdo programático integral do edital
- [ ] Definir a distribuição semanal até 20/09/2026
- [ ] Criar o diagnóstico inicial da aluna
- [ ] Concluir Administração Geral
- [ ] Concluir Português
- [ ] Concluir Direito Administrativo

## Prioridade 2

- [ ] Administração Pública
- [ ] Direito Constitucional
- [ ] Licitações e Contratos
- [ ] Informática
- [ ] Raciocínio Lógico

## Prioridade 3

- [ ] AFO
- [ ] Legislação específica
- [ ] Banco de questões consolidado
- [ ] Simulados completos
- [ ] Revisão final
